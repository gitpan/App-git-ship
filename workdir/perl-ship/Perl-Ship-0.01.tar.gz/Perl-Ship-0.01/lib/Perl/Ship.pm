package Perl::Ship;
=head1 NAME

Perl::Ship

=head1 VERSION

0.01

=cut

our $VERSION = '0.01';

1